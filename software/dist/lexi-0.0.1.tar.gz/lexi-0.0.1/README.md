# lexi
Main repository for all data analysis related to LEXI

This documents guides you through the installation of Lexi.

Though it is not necessary, we strongly recommend that you install Lexi in a virtual environment.
This will prevent any conflicts with other Python packages you may have installed.

## Creating a virtual environment
There are several ways to create a virtual environment. We recommend using `python3` or `poetry`.

For this exercise, we will assume that you have a directory called `Documents/lexi` where you will
install Lexi and create your virtual environment.

- cd into `Documents/lexi`

### Using python3
You can create a virtual environment called `lexi_venv` using `python3` by running the following command:

```bash
    python3 -m venv lexi_venv
```

You can activate the virtual environment by running the following command:

#### on Linux/MacOS:

```bash
    source lexi_venv/bin/activate
```

#### on Windows:

```bash
    .\lexi_venv\Scripts\activate.bat
```

You can deactivate the virtual environment by running the following command:

```bash
    deactivate
```

### Using poetry
You can create a virtual environment and install LEXI inside it using `poetry` by running the following command:

```bash
    poetry install
```
This will create a virtual environment and install all the dependencies listed in the `pyproject.toml` file.
- You can activate the virtual environment by running the following command:

```bash
    poetry shell
```

You can deactivate the virtual environment by running the following command:

```bash
    exit
```

## Installing Lexi

### Installing from source
After you have created and activated your virtual environment, you can install Lexi directly from GitHub by running the following command:

```bash
    pip install git+https://github.com/Lexi-BU/lexi
```

### Installing from a local copy
Copy the `lexi/dist` directory into `Documents/lexi`.

NOTE: Since we do not have proper sky background data and the ephemeris data, we have to use 
data locally available. You thus must have the following files in the `Documents/lexi` directory:
    - `data/PIT_shifted_jul08.cdf`
    - `data/sample_lexi_pointing_ephem_edited.csv`
    - `data/sample_xray_background.csv`

The `lexi/dist` directory contains a file called `lexi-0.0.1.tar.gz`, or some other version of the same file.

Activate your virtual environment uusing the instructions above.

Install Lexi by running the following command:

```bash
    pip install dist/lexi-0.0.1.tar.gz
```

## Verifying the installation
You can verify that Lexi was installed by running the following command:

```bash
    pip show lexi
```

which should produce output similar to the following:

```
    Name: lexi
    Version: 0.0.1
    Summary: Main repository for all data analysis related to LEXI
    Home-page: 
    Author: qudsiramiz
    Author-email: qudsiramiz@gmail.com
    License: GNU GPLv3
    Location: /home/vetinari/Desktop/lxi_code_test/lxi_code_testv0/lib/python3.10/site-packages
    Requires: pandas, spacepy, toml
    Required-by: 
```

You can also verify that Lexi was installed by running the following command:

```bash
    pip list
```
which should produce output similar to the following:

```bash
    Package         Version
    --------------- -------
    .....................
    lexi            0.0.1
    pandas          1.3.4
    pip             21.3.1
    .....................
```

You can open a Python shell and import Lexi by running the following command:

```bash
    python
    import lexi
    lexi.__version__
``` 

which should produce output similar to the following:

```bash
'0.0.1'
```
If that worked, congratulations! You have successfully installed Lexi.
